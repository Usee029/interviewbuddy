# InterviewBuddy: hosted version

Express server + static frontend. The browser never sees your Google AI key; it calls `/api/*`, and the server calls Google Gemini.

## Run locally
    npm install
    GEMINI_API_KEY=sk-ant-... npm start      # http://localhost:3000

## Deploy on Render (free tier works)
1. Put this folder in a GitHub repo.
2. Render > New > Web Service > pick the repo.
3. Build command: `npm install`  Start command: `npm start`
4. Environment: add `GEMINI_API_KEY` (and optionally the limits in `.env.example`).
5. Deploy. Your public link is the `onrender.com` URL.
Railway and Fly.io work the same way: set the same env vars.

## Cost protection
- `MAX_REQUESTS_PER_IP_PER_HOUR` (default 40; one full interview is about 7 calls)
- `MAX_REQUESTS_PER_DAY_TOTAL` (default 1500, a hard daily ceiling)
Free tier has daily limits, so keep the daily cap low.
